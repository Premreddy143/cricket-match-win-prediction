"""
generate_data.py
-----------------
Generates a synthetic IPL match dataset (1,000+ records) that mimics the
structure of the real Kaggle "IPL Complete Matches" dataset.

NOTE: This is a stand-in data generator so the whole pipeline runs
end-to-end out of the box. For real analysis, drop the official
Kaggle IPL dataset into this folder as `ipl_matches.csv` with the
same column names and the rest of the pipeline will work unchanged.
"""

import numpy as np
import pandas as pd

np.random.seed(42)

TEAMS = [
    "Mumbai Indians", "Chennai Super Kings", "Royal Challengers Bangalore",
    "Kolkata Knight Riders", "Delhi Capitals", "Punjab Kings",
    "Rajasthan Royals", "Sunrisers Hyderabad", "Gujarat Titans",
    "Lucknow Super Giants",
]

# messy/alternate spellings to simulate real-world dirty data
TEAM_ALIASES = {
    "Mumbai Indians": ["Mumbai Indians", "MI", "mumbai indians"],
    "Chennai Super Kings": ["Chennai Super Kings", "CSK", "Chennai Super Kings "],
    "Royal Challengers Bangalore": ["Royal Challengers Bangalore", "RCB", "Bangalore"],
    "Kolkata Knight Riders": ["Kolkata Knight Riders", "KKR"],
    "Delhi Capitals": ["Delhi Capitals", "Delhi Daredevils", "DC"],
    "Punjab Kings": ["Punjab Kings", "Kings XI Punjab", "PBKS"],
    "Rajasthan Royals": ["Rajasthan Royals", "RR"],
    "Sunrisers Hyderabad": ["Sunrisers Hyderabad", "SRH"],
    "Gujarat Titans": ["Gujarat Titans", "GT"],
    "Lucknow Super Giants": ["Lucknow Super Giants", "LSG"],
}

VENUES = [
    "Wankhede Stadium", "M. A. Chidambaram Stadium", "Eden Gardens",
    "Arun Jaitley Stadium", "M. Chinnaswamy Stadium", "Narendra Modi Stadium",
    "Rajiv Gandhi Intl. Cricket Stadium", "Punjab Cricket Association Stadium",
    "Sawai Mansingh Stadium", "BRSABV Ekana Cricket Stadium",
]

CITIES = [
    "Mumbai", "Chennai", "Kolkata", "Delhi", "Bengaluru", "Ahmedabad",
    "Hyderabad", "Mohali", "Jaipur", "Lucknow",
]

TOSS_DECISIONS = ["bat", "field"]

N_RECORDS = 1100


def team_strength():
    """Assign a latent 'strength' score per team so outcomes aren't random noise."""
    return {t: np.random.uniform(0.35, 0.75) for t in TEAMS}


def generate():
    strength = team_strength()
    rows = []

    for i in range(N_RECORDS):
        season = np.random.choice(range(2015, 2025))
        team1, team2 = np.random.choice(TEAMS, size=2, replace=False)
        venue_idx = np.random.randint(0, len(VENUES))
        venue = VENUES[venue_idx]
        city = CITIES[venue_idx]

        toss_winner = np.random.choice([team1, team2])
        toss_decision = np.random.choice(TOSS_DECISIONS, p=[0.45, 0.55])

        # win probability driven by relative strength + small home/toss effects
        p_team1 = strength[team1] / (strength[team1] + strength[team2])
        if toss_winner == team1 and toss_decision == "field":
            p_team1 += 0.05
        elif toss_winner == team2 and toss_decision == "field":
            p_team1 -= 0.05
        p_team1 = np.clip(p_team1, 0.05, 0.95)

        winner = team1 if np.random.rand() < p_team1 else team2

        # inject messy team-name variants (dirty data on purpose)
        team1_raw = np.random.choice(TEAM_ALIASES[team1])
        team2_raw = np.random.choice(TEAM_ALIASES[team2])
        toss_winner_raw = team1_raw if toss_winner == team1 else team2_raw
        winner_raw = team1_raw if winner == team1 else team2_raw

        # inject some missing values (~4% of rows) to simulate real messiness
        city_val = city if np.random.rand() > 0.04 else np.nan
        toss_decision_val = toss_decision if np.random.rand() > 0.03 else np.nan
        winner_val = winner_raw if np.random.rand() > 0.02 else np.nan

        rows.append({
            "match_id": i + 1,
            "season": season,
            "city": city_val,
            "venue": venue,
            "team1": team1_raw,
            "team2": team2_raw,
            "toss_winner": toss_winner_raw,
            "toss_decision": toss_decision_val,
            "winner": winner_val,
        })

    df = pd.DataFrame(rows)
    df.to_csv("data/ipl_matches.csv", index=False)
    print(f"Generated {len(df)} records -> data/ipl_matches.csv")


if __name__ == "__main__":
    generate()
