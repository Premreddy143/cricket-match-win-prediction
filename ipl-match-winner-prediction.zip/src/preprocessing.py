"""
preprocessing.py
-----------------
Handles:
  - Missing value imputation
  - Team name standardization (mapping aliases -> canonical names)
  - Feature engineering (toss features, venue encoding, target leakage-safe label)
"""

import os
import pandas as pd
import numpy as np

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_DEFAULT_RAW_PATH = os.path.join(_THIS_DIR, "..", "data", "ipl_matches.csv")

TEAM_NAME_MAP = {
    "MI": "Mumbai Indians", "mumbai indians": "Mumbai Indians",
    "Mumbai Indians ": "Mumbai Indians",
    "CSK": "Chennai Super Kings", "Chennai Super Kings ": "Chennai Super Kings",
    "RCB": "Royal Challengers Bangalore", "Bangalore": "Royal Challengers Bangalore",
    "KKR": "Kolkata Knight Riders",
    "Delhi Daredevils": "Delhi Capitals", "DC": "Delhi Capitals",
    "Kings XI Punjab": "Punjab Kings", "PBKS": "Punjab Kings",
    "RR": "Rajasthan Royals",
    "SRH": "Sunrisers Hyderabad",
    "GT": "Gujarat Titans",
    "LSG": "Lucknow Super Giants",
}


def standardize_team_names(df: pd.DataFrame) -> pd.DataFrame:
    """Map every known alias/abbreviation to one canonical team name."""
    df = df.copy()
    for col in ["team1", "team2", "toss_winner", "winner"]:
        df[col] = df[col].replace(TEAM_NAME_MAP).str.strip()
    return df


def handle_missing_values(df: pd.DataFrame) -> pd.DataFrame:
    """Drop rows with missing target (winner); impute categorical gaps elsewhere."""
    df = df.copy()
    df = df.dropna(subset=["winner"])  # can't train without a label
    df["city"] = df["city"].fillna(df["venue"].map(
        df.dropna(subset=["city"]).drop_duplicates("venue").set_index("venue")["city"]
    ))
    df["city"] = df["city"].fillna("Unknown")
    df["toss_decision"] = df["toss_decision"].fillna(df["toss_decision"].mode()[0])
    return df


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Build model-ready features:
      - toss_winner_is_team1: whether team1 won the toss
      - toss_decision_field: 1 if the toss winner chose to field
      - target: 1 if team1 won the match, else 0 (symmetric, no leakage)
    """
    df = df.copy()
    df["toss_winner_is_team1"] = (df["toss_winner"] == df["team1"]).astype(int)
    df["toss_decision_field"] = (df["toss_decision"] == "field").astype(int)
    df["target"] = (df["winner"] == df["team1"]).astype(int)
    return df


def build_dataset(raw_csv_path: str = _DEFAULT_RAW_PATH) -> pd.DataFrame:
    df = pd.read_csv(raw_csv_path)
    df = standardize_team_names(df)
    df = handle_missing_values(df)
    df = engineer_features(df)
    return df


if __name__ == "__main__":
    data = build_dataset()
    print(data.shape)
    print(data.head())
    data.to_csv(os.path.join(_THIS_DIR, "..", "data", "ipl_matches_clean.csv"), index=False)
