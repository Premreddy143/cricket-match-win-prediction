"""
train_models.py
----------------
Trains Logistic Regression, Decision Tree, Random Forest, and XGBoost on the
cleaned IPL dataset, compares them on Accuracy / Confusion Matrix /
Classification Report, and saves the best-performing model + encoders
for deployment in app.py.
"""

import os
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
from xgboost import XGBClassifier

from preprocessing import build_dataset

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_MODELS_DIR = os.path.join(_THIS_DIR, "..", "models")

FEATURES = [
    "team1_enc", "team2_enc", "venue_enc", "city_enc",
    "toss_winner_is_team1", "toss_decision_field",
]


def encode_features(df: pd.DataFrame):
    encoders = {}
    df = df.copy()
    for col, new_col in [("team1", "team1_enc"), ("team2", "team2_enc"),
                          ("venue", "venue_enc"), ("city", "city_enc")]:
        le = LabelEncoder()
        df[new_col] = le.fit_transform(df[col].astype(str))
        encoders[col] = le
    return df, encoders


def evaluate(name, model, X_test, y_test, results):
    preds = model.predict(X_test)
    acc = accuracy_score(y_test, preds)
    cm = confusion_matrix(y_test, preds).tolist()
    report = classification_report(y_test, preds, output_dict=True)
    results[name] = {"accuracy": acc, "confusion_matrix": cm, "report": report}
    print(f"\n=== {name} ===")
    print(f"Accuracy: {acc:.4f}")
    print("Confusion Matrix:", cm)
    print(classification_report(y_test, preds))
    return acc


def main():
    df = build_dataset()
    df, encoders = encode_features(df)

    X = df[FEATURES]
    y = df["target"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    models = {
        "Logistic Regression": LogisticRegression(max_iter=1000),
        "Decision Tree": DecisionTreeClassifier(max_depth=6, random_state=42),
        "Random Forest": RandomForestClassifier(n_estimators=200, max_depth=8, random_state=42),
        "XGBoost": XGBClassifier(
            n_estimators=200, max_depth=4, learning_rate=0.05,
            eval_metric="logloss", random_state=42
        ),
    }

    results = {}
    trained = {}
    for name, model in models.items():
        model.fit(X_train, y_train)
        trained[name] = model
        evaluate(name, model, X_test, y_test, results)

    best_name = max(results, key=lambda k: results[k]["accuracy"])
    best_model = trained[best_name]
    print(f"\nBest model: {best_name} (Accuracy: {results[best_name]['accuracy']:.4f})")

    os.makedirs(_MODELS_DIR, exist_ok=True)
    joblib.dump(best_model, os.path.join(_MODELS_DIR, "best_model.pkl"))
    joblib.dump(encoders, os.path.join(_MODELS_DIR, "encoders.pkl"))
    with open(os.path.join(_MODELS_DIR, "results.json"), "w") as f:
        json.dump({"best_model": best_name, "all_results": {
            k: {"accuracy": v["accuracy"], "confusion_matrix": v["confusion_matrix"]}
            for k, v in results.items()
        }}, f, indent=2)

    print("Saved: models/best_model.pkl, models/encoders.pkl, models/results.json")


if __name__ == "__main__":
    main()
